*19 September 2017*
-Updated to Ionic 3.6.0
-Updated resources to match new dimensions
-Added <script src="build/vendor.js"></script> to index.html
-Added some configurations in IonicModule.forRoot() in src/app/app.module.ts
-Fixed some styles in src/pages/notifications/notifications.scss
-Fix an issue with image picker plugin
