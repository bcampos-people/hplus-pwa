export class ListModel {
  name: string;
  image: string;
  description: string;
}
export class List1Model {
  items: Array<ListModel>;
}
