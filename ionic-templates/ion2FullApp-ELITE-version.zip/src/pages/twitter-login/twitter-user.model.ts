export class TwitterUserModel {
  image: string;
  name: string;
  screen_name: string;
  userId: string;
  location: string;
  description: string;
  following: number;
  followers: number;
}
